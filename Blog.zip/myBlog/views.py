from django.shortcuts import render
from myBlog.models import BlogInfo


def index(request):
    blog = BlogInfo.objects.all()
    return render(request, 'myBlog/postpage.html', {'blog' : blog})

