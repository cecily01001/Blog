from django.db import models
from ckeditor_uploader.fields import RichTextUploadingField
# Create your models here.

class BlogInfo(models.Model):
    btitle = models.CharField(max_length=100)
    bData = models.DateField()
    btag = models.CharField(max_length=50)
    isDelete = models.BooleanField(default=False)
    content = RichTextUploadingField(verbose_name='正文',default='默认值')

class ReadInfo(models.Model):
    email = models.CharField(max_length=40)
    passwprd = models.CharField(max_length=20)
    isDelete = models.BooleanField(default=False)

class TagInfo(models.Model):
    tag = models.CharField(max_length=40)
    tagc  = models.ForeignKey('BlogInfo', on_delete=models.CASCADE)
    isDelete = models.BooleanField(default=False)
# class Post(models.Model):
#     btitle = models.CharField(max_length=100)
#     btag = models.CharField(max_length=50)
#     content = RichTextUploadingField(verbose_name='正文')