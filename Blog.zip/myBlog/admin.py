from django.contrib import admin
from .models import BlogInfo

admin.site.register(BlogInfo)
# Register your models here.
